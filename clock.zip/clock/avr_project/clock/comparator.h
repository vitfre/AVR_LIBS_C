﻿/*
 * comparator.h
 *
 * Created: 26.10.2014 14:36:00
 *  Author: Evgeny
 */ 


#ifndef COMPARATOR_H_
#define COMPARATOR_H_

#include <avr/io.h>

void init_comparator();


#endif /* COMPARATOR_H_ */