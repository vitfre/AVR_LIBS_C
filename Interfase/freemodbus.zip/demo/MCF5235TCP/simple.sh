../../tools/modpoll -m tcp 10.0.10.2 -r 1000 -t 3:int 
