#define F_CPU   12000000L 
#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include "usbdrv.h"
#include "oddebug.h"


unsigned char d,d2;

void initAdc()
{
   ADCSRA=(1<<ADEN)|(1<<ADFR)|(1<<ADSC);
   ADMUX=(1<<REFS1)|(1<<REFS0)|(0<<ADLAR);
}


unsigned char GetRndDigit()
{
	unsigned char result=0;
	unsigned char i=0;
	unsigned char temp,temp1;
	for (i=1;i<=8;i++)
	 {   

	 result<<=1;
	 temp=ADCL;
	 temp1=ADCH;

    	if ((temp & 1) == 1)
    		 {
		   		result++;		
	    	 }
	  _delay_ms(15);

		
	 }
	return result;
   
}





static void hardwareInit(void)
{
uchar	i, j;

    DDRB = 0xff;


    PORTC = 0;   
    DDRC = 0;  



    PORTD = 0xfa;   /* 1111 1010 bin: activate pull-ups except on USB lines */
    DDRD = 0x07;    /* 0000 0111 bin: all pins input except USB (-> USB reset) */
	j = 0;
	while(--j){     /* USB Reset by device only required on Watchdog Reset */
		i = 0;
		while(--i); /* delay >10ms for USB reset */
	}
    DDRD = 0x02;    /* 0000 0010 bin: remove USB reset condition */
    

    TCCR1B = (1<<CS12)|(1<<CS10);
	OCR1AH = 0x2D;
	OCR1AL = 0xC6;  
	   
}

/* ------------------------------------------------------------------------- */





/* ------------------------------------------------------------------------- */
/* ----------------------------- USB interface ----------------------------- */
/* ------------------------------------------------------------------------- */

static uchar    reportBuffer[2];    /* buffer for HID reports */
static uchar    idleRate;           /* in 4 ms units */

PROGMEM char usbHidReportDescriptor[35] = { /* USB report descriptor */
    0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)
    0x09, 0x06,                    // USAGE (Keyboard)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x05, 0x07,                    //   USAGE_PAGE (Keyboard)
    0x19, 0xe0,                    //   USAGE_MINIMUM (Keyboard LeftControl)
    0x29, 0xe7,                    //   USAGE_MAXIMUM (Keyboard Right GUI)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x25, 0x01,                    //   LOGICAL_MAXIMUM (1)
    0x75, 0x01,                    //   REPORT_SIZE (1)
    0x95, 0x08,                    //   REPORT_COUNT (8)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0x95, 0x01,                    //   REPORT_COUNT (1)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x25, 0x65,                    //   LOGICAL_MAXIMUM (101)
    0x19, 0x00,                    //   USAGE_MINIMUM (Reserved (no event indicated))
    0x29, 0x65,                    //   USAGE_MAXIMUM (Keyboard Application)
    0x81, 0x00,                    //   INPUT (Data,Ary,Abs)
    0xc0                           // END_COLLECTION
};

#define NUM_KEYS    33

static const uchar  keyReport[NUM_KEYS + 1][2] PROGMEM = {
/* none */  {0, 0},                     /* no key pressed */
/*    */    {0, 4},
/*    */    {0, 5},
/*    */    {0, 6},
/*    */    {0, 7},
/*    */    {0, 8},
/*    */    {0, 9},
/*    */    {0, 10},
/*    */    {0, 11},
/*    */    {0, 12},
/*    */    {0, 13},
/*    */    {0, 14},
/*    */    {0, 15},
/*    */    {0, 16},
/*    */    {0, 17},
/*    */    {0, 18},
/*    */    {0, 19},
/*    */    {0, 20},
/*    */    {0, 21},
/*    */    {0, 22},
/*    */    {0, 23},
/*    */    {0, 24},
/*    */    {0, 25},
/*    */    {0, 26},
/*    */    {0, 27},
/*    */    {0, 28},
/*    */    {0, 29}, ////26
/*    */    {0, 47},
/*    */    {0, 48},
/*    */    {0, 51},
/*    */    {0, 52},
/*    */    {0, 53},
/*    */    {0, 54},
/*    */    {0, 55},

};

static void buildReport(uchar key)
{
/* This (not so elegant) cast saves us 10 bytes of program memory */
    *(int *)reportBuffer = pgm_read_word(keyReport[key]);
}

uchar	usbFunctionSetup(uchar data[8])
{
usbRequest_t    *rq = (void *)data;

    usbMsgPtr = reportBuffer;
    if((rq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_CLASS){    /* class request type */
        if(rq->bRequest == USBRQ_HID_GET_REPORT){  /* wValue: ReportType (highbyte), ReportID (lowbyte) */
            /* we only have one report type, so don't look at wValue */
            buildReport(d);     ////!!!!!!!!!!!!!!!!!!!!!!
            return sizeof(reportBuffer);
        }else if(rq->bRequest == USBRQ_HID_GET_IDLE){
            usbMsgPtr = &idleRate;
            return 1;
        }else if(rq->bRequest == USBRQ_HID_SET_IDLE){
            idleRate = rq->wValue.bytes[1];
        }
    }else{
        /* no vendor specific requests implemented */
    }
	return 0;
}

/* ------------------------------------------------------------------------- */

unsigned char TimerReady(void)
{
   
  if ((TIFR & 0b00010000)==0b00010000)
    {
      /// PORTB=~PORTB;
	   TCNT1=0x0000;
	   TIFR=0b00010000;
	   return 1;
	}
   else
       return 0; 

}

int	main(void)
{

	d2=0;

	
	initAdc();
	srandom(GetRndDigit());


	wdt_enable(WDTO_2S);

    hardwareInit();

	odDebugInit();
	usbInit();
	sei();
    DBG1(0x00, 0, 0);
//	while(1)
//	{
//      PORTB=GetRndDigit();
//	  _delay_ms(400);
//	}

	for(;;)
	{	/* main event loop */
		wdt_reset();
		usbPoll();
        if(TimerReady() && usbInterruptIsReady())
		{
			d=random();
			if (d<=33) 
			{ 
              PORTB=~PORTB;
			  buildReport(d);
              usbSetInterrupt(reportBuffer, sizeof(reportBuffer));

			//  while(usbInterruptIsReady()!=1)
			//   {
			 //    d2++;
			//   }
			//  buildReport(0);
            //  usbSetInterrupt(reportBuffer, sizeof(reportBuffer));			  
			}
        }
	}
	return 0;
}

/* ------------------------------------------------------------------------- */
